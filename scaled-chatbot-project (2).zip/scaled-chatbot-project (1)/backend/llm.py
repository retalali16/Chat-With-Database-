import os
from dotenv import load_dotenv
from openai import AsyncAzureOpenAI
from schema import DATABASE_SCHEMA

load_dotenv()

client = AsyncAzureOpenAI(
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
)

DEPLOYMENT = os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")


async def generate_sql(question: str, previous_error: str = None) -> str:
    """Ask the LLM to translate a natural-language question into SQL.

    If previous_error is given, the model is asked to fix its own
    last attempt instead of retrying from scratch (one correction pass).
    """
    messages = [
        {"role": "system", "content": DATABASE_SCHEMA},
        {"role": "user", "content": f"Write a SQL query to answer this question: {question}"},
    ]

    if previous_error:
        messages.append({
            "role": "user",
            "content": (
                f"That query failed with error: {previous_error}. "
                "Fix it and return ONLY the corrected raw SQL query."
            ),
        })

    response = await client.chat.completions.create(
        model=DEPLOYMENT,
        messages=messages,
        temperature=0.0,
    )

    return response.choices[0].message.content.strip()


async def generate_answer(question: str, db_result) -> str:
    """Turn raw DB rows into a natural-language answer."""
    response = await client.chat.completions.create(
        model=DEPLOYMENT,
        messages=[
            {
                "role": "system",
                "content": "You are a friendly assistant. Answer the user's question "
                            "in natural language using the provided database result.",
            },
            {
                "role": "user",
                "content": f"Question: {question}\nDatabase Result: {db_result}",
            },
        ],
        temperature=0.7,
    )

    return response.choices[0].message.content