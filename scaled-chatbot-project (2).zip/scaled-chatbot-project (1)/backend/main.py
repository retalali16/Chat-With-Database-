from dotenv import load_dotenv
load_dotenv()  # no-op in Docker (env vars come from env_file instead)

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel

from db import execute_sql
from llm import generate_sql, generate_answer
from cache import (
    get_cached_answer,
    set_cached_answer,
    get_semantic_cached_answer,
    set_semantic_cached_answer,
)

app = FastAPI(
    title="Database AI Agent API",
    description="Chat with a PostgreSQL database using Azure OpenAI (text-to-SQL).",
    version="2.0",
)


class QueryRequest(BaseModel):
    question: str


class QueryResponse(BaseModel):
    answer: str
    cached: bool = False


@app.get("/")
async def root():
    return {"message": "Database AI Agent API is running."}


@app.get("/health")
async def health():
    return {"status": "ok"}


async def chat_with_database(question: str) -> str:
    # 1. Generate SQL
    sql_query = await generate_sql(question)

    # 2. Execute it, with a single self-correction attempt on failure
    rows, error = await execute_sql(sql_query)
    if error:
        sql_query = await generate_sql(question, previous_error=error)
        rows, error = await execute_sql(sql_query)
        if error:
            return "Sorry, I couldn't answer that question."

    # 3. Turn the raw rows into a natural-language answer
    return await generate_answer(question, rows)


@app.post("/chat", response_model=QueryResponse)
async def chat_endpoint(request: QueryRequest):
    question = request.question.strip()
    if not question:
        raise HTTPException(status_code=400, detail="Question cannot be empty.")

    # 1. Exact match — cheapest, catches identical repeated questions
    cached = await get_cached_answer(question)
    if cached:
        return QueryResponse(answer=cached, cached=True)

    # 2. Semantic match — catches paraphrased/reworded questions
    semantic_cached = await get_semantic_cached_answer(question)
    if semantic_cached:
        await set_cached_answer(question, semantic_cached)  # promote to exact cache too
        return QueryResponse(answer=semantic_cached, cached=True)

    # 3. Full pipeline: nothing cached, ask the LLM + query the DB
    answer = await chat_with_database(question)
    await set_cached_answer(question, answer)
    await set_semantic_cached_answer(question, answer)
    return QueryResponse(answer=answer, cached=False)
